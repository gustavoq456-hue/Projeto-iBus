// Relações direcionais da tabela da equipe, sem inversão automática.
const ROTAS = {
  "Centro": [
    "Silvestre",
    "Novo Silvestre",
    "Nova Viçosa",
    "Acamari",
    "Violeira",
    "Paraíso",
    "Santa Clara",
    "São José do Triunfo",
    "Córrego Fundo",
    "Pau de Cedro",
    "Duas Barras",
    "Coelhas"
  ],
  "Rodoviária": [
    "Silvestre",
    "Novo Silvestre",
    "Nova Viçosa",
    "Acamari",
    "Violeira",
    "Paraíso",
    "Santa Clara",
    "São José do Triunfo",
    "Córrego Fundo",
    "Pau de Cedro",
    "Duas Barras",
    "Coelhas"
  ],
  "UFV": [
    "Silvestre",
    "Novo Silvestre",
    "Nova Viçosa",
    "Acamari",
    "Violeira",
    "Paraíso",
    "Santa Clara",
    "São José do Triunfo",
    "Córrego Fundo",
    "Pau de Cedro",
    "Duas Barras",
    "Coelhas"
  ],
  "Silvestre": [
    "UFV",
    "Centro",
    "Acamari",
    "Nova Viçosa",
    "Posses"
  ],
  "Novo Silvestre": [
    "UFV",
    "Centro",
    "Acamari",
    "Nova Viçosa",
    "Posses"
  ],
  "Nova Viçosa": [
    "Centro",
    "Novo Silvestre"
  ],
  "Posses": [
    "Centro",
    "Novo Silvestre"
  ],
  "Acamari": [
    "Centro",
    "Rodoviária",
    "Silvestre",
    "Novo Silvestre"
  ],
  "Cachoeirinha": [
    "Centro",
    "Rodoviária",
    "Silvestre",
    "Novo Silvestre"
  ],
  "Amoras": [
    "Centro",
    "Sagrada Família",
    "Conceição"
  ],
  "Vau Açu": [
    "Centro",
    "Sagrada Família",
    "Conceição"
  ],
  "Violeira": [
    "Centro",
    "Rodoviária",
    "Bahamas",
    "Palmital"
  ],
  "Buieié": [
    "Centro",
    "Rodoviária",
    "Bahamas",
    "Palmital"
  ],
  "Paraíso": [
    "Centro",
    "Rodoviária",
    "Bahamas",
    "Palmital"
  ],
  "Santa Clara": [
    "Centro",
    "Rodoviária",
    "Bom Jesus"
  ],
  "Barrinha": [
    "Centro",
    "Rodoviária",
    "Bom Jesus"
  ],
  "São José do Triunfo": [
    "Rodoviária",
    "Centro"
  ],
  "Córrego Fundo": [
    "Centro",
    "Rodoviária"
  ],
  "Pau de Cedro": [
    "Centro",
    "Rodoviária"
  ],
  "Duas Barras": [
    "Centro",
    "Rodoviária"
  ],
  "Coelhas": [
    "Centro",
    "Rodoviária"
  ]
};
