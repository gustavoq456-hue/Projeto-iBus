// Conta e diálogos comuns às quatro páginas.
const $=id=>document.getElementById(id);
const esc=t=>String(t).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let cadastro=false;
function avisar(t){$('toast').textContent=t;$('toast').hidden=false;clearTimeout(avisar.timer);avisar.timer=setTimeout(()=>$('toast').hidden=true,6000);}
function atualizarConta(){const u=Banco.usuario();$('conta').textContent=u?u.nome.split(' ')[0]+' · Sair':'Entrar / cadastrar';}
function contaMudou(){atualizarConta();document.dispatchEvent(new Event('conta-alterada'));}
document.querySelectorAll('[data-fechar]').forEach(b=>b.onclick=()=>$(b.dataset.fechar).close());$('ver-termos').onclick=()=>$('termos').showModal();$('termos-login').onclick=()=>$('termos').showModal();
$('conta').onclick=()=>{try{if(Banco.usuario()){if(confirm('Sair da conta?')){Banco.sair();contaMudou();}}else $('login').showModal();}catch{avisar('Armazenamento local indisponível.');}};
$('alternar-login').onclick=()=>{cadastro=!cadastro;$('campo-nome').hidden=!cadastro;$('campo-aceite').hidden=!cadastro;$('nome').required=cadastro;$('aceite').required=cadastro;$('titulo-login').textContent=cadastro?'Criar conta':'Entrar na iBus';$('enviar-login').textContent=cadastro?'Cadastrar':'Entrar';$('alternar-login').textContent=cadastro?'Já tenho conta':'Ainda não tenho conta';$('senha').autocomplete=cadastro?'new-password':'current-password';$('erro-login').textContent='';};
$('form-login').onsubmit=async e=>{e.preventDefault();$('enviar-login').disabled=true;$('erro-login').textContent='';try{if(cadastro){if(!$('aceite').checked)throw Error('Aceite os termos.');await Banco.cadastrar($('nome').value,$('email').value,$('senha').value);}else await Banco.entrar($('email').value,$('senha').value);contaMudou();$('login').close();$('form-login').reset();avisar('Conta local conectada.');}catch(error){$('erro-login').textContent=error.message;}finally{$('enviar-login').disabled=false;}};
try{atualizarConta();}catch{avisar('Habilite armazenamento local para contas e favoritos.');}
