// Contas locais de demonstração. Não substituem autenticação em servidor.
const Banco={
 ler(k,p=[]){return JSON.parse(localStorage.getItem('ibus_'+k)||JSON.stringify(p));},
 salvar(k,v){localStorage.setItem('ibus_'+k,JSON.stringify(v));},
 usuario(){return this.ler('usuarios').find(u=>u.id===sessionStorage.getItem('ibus_sessao'))||null;},
 async hash(senha,salt){if(!globalThis.crypto?.subtle)throw Error('Abra pelo Live Server/localhost para cadastrar com criptografia.');const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(senha),'PBKDF2',false,['deriveBits']);const bits=await crypto.subtle.deriveBits({name:'PBKDF2',salt:new Uint8Array(salt),iterations:120000,hash:'SHA-256'},key,256);return Array.from(new Uint8Array(bits)).map(x=>x.toString(16).padStart(2,'0')).join('');},
 async cadastrar(nome,email,senha){nome=nome.trim();email=email.trim().toLowerCase();if(nome.length<2||nome.length>100)throw Error('Informe um nome válido.');if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))throw Error('E-mail inválido.');if(senha.length<8||senha.length>128)throw Error('Use senha com 8 a 128 caracteres.');const lista=this.ler('usuarios');if(lista.some(u=>u.email===email))throw Error('E-mail já cadastrado.');const salt=Array.from(crypto.getRandomValues(new Uint8Array(16)));lista.push({id:crypto.randomUUID(),nome,email,salt,hash:await this.hash(senha,salt),aceite:new Date().toISOString()});this.salvar('usuarios',lista);sessionStorage.setItem('ibus_sessao',lista.at(-1).id);},
 async entrar(email,senha){const u=this.ler('usuarios').find(u=>u.email===email.trim().toLowerCase());if(!u||await this.hash(senha,u.salt)!==u.hash)throw Error('E-mail ou senha incorretos.');sessionStorage.setItem('ibus_sessao',u.id);},
 sair(){sessionStorage.removeItem('ibus_sessao');},
 favoritos(){const u=this.usuario();return u?this.ler('trajetos_v2_'+u.id):[];},
 salvarFavorito(caminho){const u=this.usuario();if(!u)throw Error('Entre na conta para favoritar.');if(!validarCaminho(caminho))throw Error('Trajeto não permitido.');const f=this.favoritos();if(f.some(x=>JSON.stringify(x.caminho)===JSON.stringify(caminho)))throw Error('Esse trajeto já está nos favoritos.');f.unshift({id:crypto.randomUUID(),caminho:[...caminho]});this.salvar('trajetos_v2_'+u.id,f);},
 removerFavorito(id){const u=this.usuario();if(!u)throw Error('Entre na conta.');this.salvar('trajetos_v2_'+u.id,this.favoritos().filter(f=>f.id!==id));},
 sugestoes(){const u=this.usuario();return u?this.ler('sugestoes_'+u.id):[];},
 sugerir(texto){const u=this.usuario();if(!u)throw Error('Entre na conta para salvar a sugestão.');texto=texto.trim();if(texto.length<10||texto.length>2000)throw Error('Escreva entre 10 e 2000 caracteres.');this.salvar('sugestoes_'+u.id,[...this.sugestoes(),{id:crypto.randomUUID(),texto,data:new Date().toISOString()}]);}
};
