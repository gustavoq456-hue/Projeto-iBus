// O mapa é fixo; o resumo acompanha o caminho selecionado.
let origem='Centro',destinos=[''];
function guardarRascunho(){try{sessionStorage.setItem('ibus_rascunho_v3',JSON.stringify({origem,destinos}));}catch{}}
function restaurarRascunho(){try{const r=JSON.parse(sessionStorage.getItem('ibus_rascunho_v3')||'null');if(!r||!ROTAS[r.origem]||!Array.isArray(r.destinos))return;origem=r.origem;destinos=[];let atual=origem;for(const d of r.destinos){if(d===''){destinos.push('');break;}if(!destinosPermitidos(atual).includes(d))break;destinos.push(d);atual=d;}if(!destinos.length)destinos=[''];}catch{}}
function limparResumo(){$('resumo').innerHTML='<h2>Seu caminho está sendo montado</h2><p>Escolha os destinos e toque em “Ver meu trajeto”.</p>';}
function mudarAba(n){document.querySelectorAll('[data-aba]').forEach(b=>b.classList.toggle('ativa',b.dataset.aba===n));$('aba-planejar').hidden=n!=='planejar';$('aba-favoritos').hidden=n!=='favoritos';if(n==='favoritos')mostrarFavoritos();}
function desenharTrechos(){
 const el=$('trechos');el.replaceChildren();
 destinos.forEach((destino,i)=>{
  const atual=i?destinos[i-1]:origem,div=document.createElement('div');div.className='trecho-form';
  div.innerHTML='<div class="trecho-topo"><strong>Trecho '+(i+1)+'</strong></div><p class="origem-atual">Saída: '+esc(atual)+'</p>';
  if(i){const b=document.createElement('button');b.type='button';b.textContent='Remover daqui em diante';b.onclick=()=>{destinos=destinos.slice(0,i);limparResumo();desenharTrechos();};div.querySelector('.trecho-topo').append(b);}
  const label=document.createElement('label');label.htmlFor='destino-'+i;label.textContent=i?'Próximo destino':'Primeiro destino';
  const select=document.createElement('select');select.id='destino-'+i;select.required=true;select.innerHTML='<option value="">Selecione o destino</option>'+destinosPermitidos(atual).map(n=>'<option value="'+esc(n)+'">'+esc(n)+'</option>').join('');select.value=destino;
  select.onchange=()=>{destinos[i]=select.value;destinos=destinos.slice(0,i+1);limparResumo();desenharTrechos();};div.append(label,select);el.append(div);
 });
 const ultimo=destinos.at(-1),continuar=!!ultimo&&destinosPermitidos(ultimo).length>0;$('adicionar').disabled=!continuar;$('planejar-botao').disabled=!destinos.every(Boolean);$('ajuda').textContent=!ultimo?'Selecione o destino.':continuar?'Se precisar, adicione outro destino.':'Sem continuação cadastrada para '+ultimo+'.';guardarRascunho();
}
function exibirResumo(caminho){
 if(!validarCaminho(caminho))return avisar('Revise o trajeto.');
 $('resumo').innerHTML='<h2>Seu trajeto escolhido</h2><p>'+(caminho.length-1)+' trecho(s) planejado(s)</p>'+caminho.slice(0,-1).map((n,i)=>'<div class="etapa"><span class="bolinha">'+(i+1)+'</span><div><strong>'+esc(n)+' → '+esc(caminho[i+1])+'</strong><p class="small">'+(i?'Saída a partir do destino anterior.':'Início da viagem.')+'</p></div></div>').join('')+'<p><strong>Destino final:</strong> '+esc(caminho.at(-1))+'</p><p class="small">Esta é a sequência escolhida. O mapa acima é um exemplo fixo, sem relação geográfica com esse caminho. Não confirma linhas, horários ou quantidade de ônibus.</p><button id="salvar-favorito" class="azul">Favoritar trajeto completo</button>';
 $('salvar-favorito').onclick=()=>{try{Banco.salvarFavorito(caminho);mostrarFavoritos();avisar('Trajeto salvo.');}catch(e){avisar(e.message);if(!Banco.usuario())$('login').showModal();}};
}
function mostrarFavoritos(){
 const el=$('favoritos');el.replaceChildren();if(!Banco.usuario()){el.textContent='Entre na conta para consultar favoritos.';return;}const lista=Banco.favoritos();if(!lista.length){el.textContent='Você ainda não salvou um trajeto.';return;}
 lista.forEach(f=>{const div=document.createElement('article');div.className='cartao';const p=document.createElement('p');p.textContent=f.caminho.join(' → ');const abrir=document.createElement('button');abrir.className='azul';abrir.textContent='Abrir trajeto';abrir.onclick=()=>{if(!validarCaminho(f.caminho))return avisar('Favorito não é mais válido.');origem=f.caminho[0];destinos=f.caminho.slice(1);$('origem').value=origem;desenharTrechos();mudarAba('planejar');exibirResumo(f.caminho);};const remover=document.createElement('button');remover.textContent='Remover';remover.onclick=()=>{try{Banco.removerFavorito(f.id);mostrarFavoritos();}catch(e){avisar(e.message);}};div.append(p,abrir,remover);el.append(div);});
}
restaurarRascunho();$('origem').innerHTML=Object.keys(ROTAS).sort((a,b)=>a.localeCompare(b,'pt-BR')).map(n=>'<option value="'+esc(n)+'">'+esc(n)+'</option>').join('');$('origem').value=origem;
$('origem').onchange=()=>{origem=$('origem').value;destinos=[''];limparResumo();desenharTrechos();};$('adicionar').onclick=()=>{const ultimo=destinos.at(-1);if(!ultimo||!destinosPermitidos(ultimo).length)return;destinos.push('');limparResumo();desenharTrechos();$('destino-'+(destinos.length-1)).focus();};$('form-trajeto').onsubmit=e=>{e.preventDefault();exibirResumo([origem,...destinos]);};document.querySelectorAll('[data-aba]').forEach(b=>b.onclick=()=>mudarAba(b.dataset.aba));document.addEventListener('conta-alterada',mostrarFavoritos);desenharTrechos();if(destinos.every(Boolean))exibirResumo([origem,...destinos]);
