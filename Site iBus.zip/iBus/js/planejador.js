// Cada trecho deve respeitar a relação direcional cadastrada.
function destinosPermitidos(origem){return ROTAS[origem]||[];}
function validarCaminho(caminho){if(!Array.isArray(caminho)||caminho.length<2)return false;for(let i=0;i<caminho.length-1;i++)if(!destinosPermitidos(caminho[i]).includes(caminho[i+1]))return false;return true;}
